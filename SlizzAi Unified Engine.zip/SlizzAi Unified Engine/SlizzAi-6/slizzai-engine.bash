docker build -t slizzai-engine:latest docker/
docker run -p 8000:8000 slizzai-engine:latest