python setup.py sdist bdist_wheel
pip install dist/slizzaiengine-0.1.0-py3-none-any.whl